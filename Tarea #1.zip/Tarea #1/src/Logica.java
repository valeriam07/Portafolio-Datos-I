public class Logica {
    //while (i < linea.length()) {

    //System.out.println("length = " + linea.length());
    //System.out.println(linea.toCharArray()[i]);

                            /*if ((linea.toCharArray()[i] == separacion.toCharArray()[0])) {

                                //System.out.println("aparecio una separacion");

                                modelo.addColumn(linea.substring(ii, i));
                                ii = i;
                                i++;

                                //System.out.println("ii es:" + ii);

                            } else if (i == linea.length() - 1) {
                                modelo.addColumn(linea.substring(ii+1, i+1));
                                i++;
                                n++;
                            } else {

                                //System.out.println(i);

                                i++;
                            }
                        }*/
}
